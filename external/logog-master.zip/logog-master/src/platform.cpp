 /* 
 * \file platform.cpp
 */

#include "logog.hpp"

namespace logog {

	bool sb_AvoidLinkError4221_platform_cpp = false;
}

