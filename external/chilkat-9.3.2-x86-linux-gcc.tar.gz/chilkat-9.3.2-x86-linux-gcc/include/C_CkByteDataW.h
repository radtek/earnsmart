#ifndef _CkByteData_W_H
#define _CkByteData_W_H
#include "Chilkat_C.h"

HCkByteDataW CkByteDataW_Create(void);
void CkByteDataW_Dispose(HCkByteDataW handle);
#endif
