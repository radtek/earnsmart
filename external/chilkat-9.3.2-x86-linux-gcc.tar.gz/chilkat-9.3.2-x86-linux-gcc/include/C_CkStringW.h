#ifndef _CkString_W_H
#define _CkString_W_H
#include "Chilkat_C.h"

HCkStringW CkStringW_Create(void);
void CkStringW_Dispose(HCkStringW handle);
#endif
