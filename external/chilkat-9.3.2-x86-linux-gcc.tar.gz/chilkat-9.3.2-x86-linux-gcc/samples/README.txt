Chilkat example programs are available online at:
C++ Examples:  http://www.example-code.com/vcpp/default.asp
C Examples:  http://www.example-code.com/c/default.asp

