// Copyright (c) Microsoft Open Technologies, Inc. All rights reserved. See License.txt in the project root for license information.


// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "MfcTimeFliesLikeAnArrow.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
    ON_WM_CREATE()
//  ON_WM_SETFOCUS()
    ON_WM_CLOSE()
    ON_WM_MOUSEMOVE()
    ON_WM_PAINT()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}


// inspired by: http://minirx.codeplex.com/
void CMainFrame::UserInit()
{
    auto worker = std::make_shared<rxcpp::EventLoopScheduler>();
    auto mainFormScheduler = std::make_shared<rxcpp::win32::WindowScheduler>();
    auto mouseMove = BindEventToObservable(mouseMoveEvent);

    // set up labels and query
    auto msg = L"Time flies like an arrow";

#if LABEL_EXPRESSION_TRACING
    auto start = worker->Now();
    auto ms = std::chrono::milliseconds(1);
#endif

    for (int i = 0; msg[i]; ++i)
    {
        auto label = CreateLabelFromLetter(msg[i], this);

        // note: distinct_until_changed is necessary; while 
        //  Winforms filters duplicate mouse moves, 
        //  user32 doesn't filter this for you: http://blogs.msdn.com/b/oldnewthing/archive/2003/10/01/55108.aspx

        auto s = rxcpp::from(mouseMove)
            .select([=](MouseMoveEventValue e) { 
                auto now = worker->Now();
#if LABEL_EXPRESSION_TRACING
                {std::wstringstream out;
                out << L"input index: " << i << L", ms: " << ((now - start) / ms)
                    << L", x: " << e.point.x << L", y: " << e.point.y 
                    << L", x: " << e.point.x+20*i << L", y: " << e.point.y-20 << std::endl;
                OutputDebugString(out.str().c_str());}
#endif
                return std::make_tuple(now, e.point); })
            .distinct_until_changed()   
            .delay(std::chrono::milliseconds(i * 100 + 1),  worker)
#if LABEL_EXPRESSION_TRACING
            .select(rxcpp::MakeTupleDispatch([=](rxcpp::Scheduler::clock::time_point time, CPoint point) {
                {std::wstringstream out;
                out << L"delayed index: " << i << L", ms: " << ((time - start) / ms)
                    << L", x: " << point.x << L", y: " << point.y 
                    << L", x: " << point.x+20*i << L", y: " << point.y-20 << std::endl;
                OutputDebugString(out.str().c_str());}
                return std::make_tuple(time, point);;}))
#endif
            .observe_on(mainFormScheduler)
            .subscribe(rxcpp::MakeTupleDispatch([=](rxcpp::Scheduler::clock::time_point time, CPoint point) 
            {
#if LABEL_EXPRESSION_TRACING
                {std::wstringstream out;
                out << L"observed index: " << i << L", ms: " << ((time - start) / ms)
                    << L", x: " << point.x << L", y: " << point.y 
                    << L", x: " << point.x+20*i << L", y: " << point.y-20 << std::endl;
                OutputDebugString(out.str().c_str());}
#endif
                label->SetWindowPos(nullptr, point.x+20*i, point.y-20, 20, 30, SWP_NOOWNERZORDER);
                label->Invalidate();

                // repaint early, for fluid animation
                //label->UpdateWindow();
                this->UpdateWindow();
            }));

        composableDisposable.Add(std::move(s));
    }
}

void CMainFrame::OnClose()
{
    // shutdown subscription.
    composableDisposable.Dispose();
    
    CFrameWnd::OnClose();
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;

	if (!m_wndStatusBar.Create(this))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	m_wndStatusBar.SetIndicators(indicators, sizeof(indicators)/sizeof(UINT));

    UserInit();

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, ::LoadCursor(NULL, IDC_ARROW));
	return TRUE;
}

// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}
#endif //_DEBUG


// CMainFrame message handlers

void CMainFrame::OnSetFocus(CWnd* /*pOldWnd*/)
{
	// forward focus to the view window
	//m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// let the view have first crack at the command
	//if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
	//	return TRUE;

	// otherwise, do default handling
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}

void CMainFrame::OnMouseMove(UINT nFlags, CPoint point)
{
    MouseMoveEventValue v = {nFlags, point};
    this->mouseMoveEvent(v);
}

void CMainFrame::OnPaint( )
{
    CPaintDC dc(this); // device context for painting
	
    RECT rc;
    this->GetClientRect(&rc);
    CBrush brush;
    brush.CreateSolidBrush(RGB(240,240,240));
    dc.FillRect(&rc, &brush);
}

