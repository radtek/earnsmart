#include "../src/easylogging++.cc"
