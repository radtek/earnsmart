#ifndef _LIBGEN_H
#define _LIBGEN_H

char * basename (char *fname)
{
  return fname;
}

#endif // _LIBGEN_H
